#include "dmaWriteRead_TB.h"
int sc_main (int argc , char *argv[]) {
   dmaWriteRead_TB SPP1("dmaWriteRead1");
   sc_start();
   return 0;
}

